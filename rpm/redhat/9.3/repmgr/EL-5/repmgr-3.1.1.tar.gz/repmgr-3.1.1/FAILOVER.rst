The contents of this file have been incorporated into the main README.md document.
