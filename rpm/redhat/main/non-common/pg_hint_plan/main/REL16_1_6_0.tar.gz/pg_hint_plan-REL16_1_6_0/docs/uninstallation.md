# Uninstallation

`make uninstall` in the top directory of source tree will uninstall the
installed files if you installed from the source tree and it is left
available.  Setting the environment variable `PATH` may be necessary.

    $ cd pg_hint_plan-1.x.x
    $ su
    $ make uninstall
