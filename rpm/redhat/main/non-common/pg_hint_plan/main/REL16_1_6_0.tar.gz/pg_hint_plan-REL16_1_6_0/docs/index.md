# pg_hint_plan 1.6

```{contents} Table of Contents
:depth: 2
```

```{toctree}
synopsis.md
description.md
hint_table.md
installation.md
uninstallation.md
hint_details.md
errors.md
functional_limitations.md
requirements.md
hint_list.md
```
